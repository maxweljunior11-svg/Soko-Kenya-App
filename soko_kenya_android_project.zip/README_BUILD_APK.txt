SOKO KENYA — ANDROID PROJECT
============================

This is the Android Studio project source for a first installable-app prototype.
It is NOT a compiled APK, and it does NOT process real M-Pesa payments.

WHAT IS INCLUDED
- Android WebView shell with Soko Kenya marketplace UI
- Local HTML assets for browsing and demo checkout
- Local browser storage for prototype listings/cart

BUILD AN APK
1. On a computer, install Android Studio from https://developer.android.com/studio
2. Extract this ZIP.
3. In Android Studio choose Open and select the extracted SokoKenya folder.
4. Allow Gradle sync and install any requested Android SDK platform (API 35).
5. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show a notification with a link to the APK output.
7. Copy the APK to your Android phone and install it. Your phone may ask you to
   allow installation from that file manager/browser.

IMPORTANT
- This project needs Android Studio/Android SDK and an internet connection for
  the first Gradle sync. This environment could prepare the source project but
  could not compile/sign the APK itself.
- Demo checkout is not connected to Safaricom. Never enter real payment secrets
  into the app. Real Daraja integration needs a server-side backend, secure
  secret storage, callback verification, and Safaricom production approval.
- Listings stored in localStorage are only on that device; this is not yet a
  multi-user marketplace with cloud accounts/database.
